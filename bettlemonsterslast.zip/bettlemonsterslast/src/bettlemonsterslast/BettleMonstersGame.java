/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bettlemonsterslast;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author adaozcelik
 */
public class BettleMonstersGame {
    ChainingHashTable allMonsters;
    Player player1, player2;
    Scanner scanner;

    public BettleMonstersGame() {
        this.allMonsters = new ChainingHashTable(100); 
        this.scanner = new Scanner(System.in);
    }

    public void initializeMonsters(String filePath) {
        try (BufferedReader bufferreader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = bufferreader.readLine()) != null) {
                int id = Integer.parseInt(line.trim());
                String name = bufferreader.readLine().trim();
                int health = Integer.parseInt(bufferreader.readLine().trim());
                int attack = Integer.parseInt(bufferreader.readLine().trim());
                int defense = Integer.parseInt(bufferreader.readLine().trim());
                int level = Integer.parseInt(bufferreader.readLine().trim());
                Monster monster = new Monster(id, name, health, attack, defense, level);
                allMonsters.add(monster);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void beginGame(String name1, String name2) {
        player1 = new Player(name1);
        player2 = new Player(name2);

        System.out.println("Each player must choose 10 monsters.");

        chooseMonsters(player1);
        chooseMonsters(player2);

        int player1Wins = 0;
        int player2Wins = 0;

        while (player1.monsters.size() > 0 && player2.monsters.size() > 0 && player1Wins < 3 && player2Wins < 3) {
            System.out.println("Player 1, choose your monster to begin with:");
            Monster monster1 = chooseMonster(player1);
            System.out.println("Player 2, choose your monster to begin with:");
            Monster monster2 = chooseMonster(player2);

            Monster winner = battle(monster1, monster2);

            if (winner == monster1) {
                System.out.println("Player 1's monster" + monster1.name + " wins the battle");
                monster1.levelUp();
                player2.removeMonster(monster2.id);
                player1Wins++;
                player2Wins = 0; 
            } else {
                System.out.println("Player 2's monster " + monster2.name + " wins the battle");
                monster2.levelUp();
                player1.removeMonster(monster1.id);
                player2Wins++;
                player1Wins = 0; 
            }
        player1.removeDeadMonsters(); 
        player2.removeDeadMonsters();
        
            showMonsterAttributes(monster1);
            showMonsterAttributes(monster2);
        }

        if (player1.monsters.size() == 0) {
            System.out.println("Player 1's monster count is zero! The game is won by Player 2!");
        } else if (player2.monsters.size() == 0) {
            System.out.println("Player 2's monster count is zero! The game is won by Player 1!");
        } else if (player1Wins == 3) {
            System.out.println("Player 1 wins in three straight fights! The game is won by Player 1!");
        } else if (player2Wins == 3) {
            System.out.println("Player 2 wins in three straight fights! The game is won by Player 2!");
        }
    }

    private void chooseMonsters(Player player) {
        for (int i = 0; i < 10; i++) {
            System.out.println("Enter the monsters ID to select:");
            int id = scanner.nextInt();
            Monster monster = allMonsters.search(id);
            if (monster != null) {
                player.addMonster(monster);
                System.out.println("Added the monster " + monster.name + " to " + player.name + "'s list.");
            } else {
                System.out.println("Monster identity not found. Please try again.");
                i--; 
            }
        }
    }

    private Monster chooseMonster(Player player) {
    System.out.println("Choose an attribute(name, health, attack, defense, level) to sort the creatures:");
    String attribute = scanner.next();
    player.obtainSortedMonsters(attribute);

    System.out.println("To select a monster for battle, enter its ID:");
    int id = scanner.nextInt();

    Monster selectedMonster = null;
    for (Monster m : player.monsters) {
        if (m.id == id) {
            selectedMonster = m;
            break;
        }
    }

    if (selectedMonster == null) {
        System.out.println("No valid ID.. Choosing the first monster in the list.");
        selectedMonster = player.monsters.getFirst();
    }

    return selectedMonster;
}


    private Monster battle(Monster monster1, Monster monster2) {
    
    int damageMonster1 = monster2.attack - monster1.defense;
    int damageMonster2 = monster1.attack - monster2.defense;

    
    if (damageMonster1 < 0) damageMonster1 = 0;
    if (damageMonster2 < 0) damageMonster2 = 0;

   
    monster1.health = monster1.health-damageMonster1;
    monster2.health = monster2.health-damageMonster2;

 
    System.out.println("Damage to Monster 1 is: " + damageMonster1);
    System.out.println("Damage to Monster 2 is: " + damageMonster2);
    System.out.println("Monster 1's Health is: " + monster1.health);
    System.out.println("Monster 2's Health is: " + monster2.health);

    if (monster1.health ==monster2.health ) {
        System.out.println("The two creatures are dead! It is a draw.");
        return null; 
    } else if (monster1.health <monster2.health) {
        System.out.println("Player 2's monster " + monster2.name + " wins the battle!");
        return monster2; 
    } else if (monster2.health <monster1.health) {
        System.out.println("Player 1's monster" + monster1.name + " wins the battle!");
        return monster1; 
    } 
    return null; 
}

    private void showMonsterAttributes(Monster monster) {
        System.out.println("Features of the monster following the battle:");
        System.out.println(monster);
    }
    
}
