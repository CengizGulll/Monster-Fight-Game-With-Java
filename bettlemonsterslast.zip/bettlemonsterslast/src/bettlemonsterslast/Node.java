/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bettlemonsterslast;

/**
 *
 * @author adaozcelik
 */
public class Node {
    Monster data;
    public Node next;

    public Node(Monster data) {
        this.data = data;
        this.next = null;
    }

    @Override
    public String toString() {
        String s = "";
        s += "Node with data: " + data;
        return s; 
    }

    
    
    
    
    
}

