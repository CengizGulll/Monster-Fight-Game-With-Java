/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bettlemonsterslast;

/**
 *
 * @author adaozcelik
 */
public class bettlemonsterslast {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BettleMonstersGame game = new BettleMonstersGame();
        game.initializeMonsters( "/Users/adaozcelik/Desktop/txtklasörü/monsters.txt"); 

        game.beginGame("Player1", "Player2");

    }
    
}
