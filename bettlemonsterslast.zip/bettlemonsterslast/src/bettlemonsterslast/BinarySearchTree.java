package bettlemonsterslast;
/**
 *
 * @author adaozcelik
 */
public class BinarySearchTree {
    private BSTNode root;
    private String attribute;

    public BinarySearchTree() {
        root = null;
        attribute = ""; 
    }

    public void insert(Monster monster, String attribute) {
        this.attribute = attribute; 
        root = insertAccounts(root, monster);
    }

    private BSTNode insertAccounts(BSTNode root, Monster monster) {
        if (root == null) {
            root = new BSTNode(monster);
            return root;
        }

        if (monster.compareTo(root.data, attribute) < 0) {
            root.left = insertAccounts(root.left, monster);
        } else {
            root.right = insertAccounts(root.right, monster);
        }

        return root;
    }

    public void traverseInOrder() {
        recursiveInOrder(root);
    }

    private void recursiveInOrder(BSTNode root) {
        if (root != null) {
            recursiveInOrder(root.left);
            showMonster(root.data);
            recursiveInOrder(root.right);
        }
    }

    private void showMonster(Monster monster) {
        switch (attribute.toLowerCase()) {
            case "name":
                System.out.printf("ID: %d, Name: %s%n", monster.id, monster.name);
                break;
            case "health":
                System.out.printf("ID: %d, Health: %d%n", monster.id, monster.health);
                break;
            case "attack":
                System.out.printf("ID: %d, Attack: %d%n", monster.id, monster.attack);
                break;
            case "defense":
                System.out.printf("ID: %d, Defense: %d%n", monster.id, monster.defense);
                break;
            case "level":
                System.out.printf("ID: %d, Level: %d%n", monster.id, monster.level);
                break;
            default:
                System.out.println("Wrong attribute: " + attribute);
                break;
        }
    }
}
