/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bettlemonsterslast;



/**
 *
 * @author adaozcelik
 */
public class ChainingHashTable {
    private LinkedList[] table;
    private int size;

    public ChainingHashTable(int size) {
        this.size = size;
        table = new LinkedList[size];
        for (int i = 0; i < size; i++) {
            table[i] = new LinkedList();
        }
    }

    private int hash(int id) {
        return id % size;
    }

    public void add(Monster monster) {
        int index = hash(monster.id);
        table[index].insertLast(monster); 
    }

    public void remove(int id) {
        int index = hash(id);
        Node prev = null;
        Node current = table[index].first;
        while (current != null) {
            if (current.data.id == id) {
                if (prev == null) {
                    table[index].removeFirst();
                } else {
                    table[index].removeAfter(prev);
                }
                return;
            }
            prev = current;
            current = current.next;
        }
    }

    public Monster search(int id) {
        int index = hash(id);
        Node current = table[index].first;
        while (current != null) {
            if (current.data.id == id) {
                return current.data;
            }
            current = current.next;
        }
        return null;
    }
}
