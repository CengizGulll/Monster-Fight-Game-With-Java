/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bettlemonsterslast;

/**
 *
 * @author adaozcelik
 */
public class Monster {
    int id;
    String name;
    int health;
    int attack;
    int defense;
    int level;

    public Monster(int id, String name, int health, int attack, int defense, int level) {
        this.id = id;
        this.name = name;
        this.health = health;
        this.attack = attack;
        this.defense = defense;
        this.level = level;
    }

    public void levelUp() {
        this.health += 3;
        this.attack += 1;
        this.defense += 2;
        this.level += 1;
    }

    public int compareTo(Monster other, String attribute) {
        switch (attribute.toLowerCase()) {
            case "name":
                return this.name.compareTo(other.name);
            case "health":
                return Integer.compare(this.health, other.health);
            case "attack":
                return Integer.compare(this.attack, other.attack);
            case "defense":
                return Integer.compare(this.defense, other.defense);
            case "level":
                return Integer.compare(this.level, other.level);
            default:
                throw new IllegalArgumentException("Wrong attribute: " + attribute);
        }
    }

    @Override
    public String toString() {
        return String.format("ID: %d, Name: %s, Health: %d, Attack: %d, Defense: %d, Level: %d",
                id, name, health, attack, defense, level);
    }
}
