/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bettlemonsterslast;

import java.util.LinkedList;

public class Player {
    String name;
    LinkedList<Monster> monsters;
    BinarySearchTree bstName;
    BinarySearchTree bstHealth;
    BinarySearchTree bstAttack;
    BinarySearchTree bstDefense;
    BinarySearchTree bstLevel;

    public Player(String name) {
        this.name = name;
        this.monsters = new LinkedList<>();
        this.bstName = new BinarySearchTree();
        this.bstHealth = new BinarySearchTree();
        this.bstAttack = new BinarySearchTree();
        this.bstDefense = new BinarySearchTree();
        this.bstLevel = new BinarySearchTree();
    }

    public void addMonster(Monster monster) {
        monsters.add(monster);
        recreateTrees();
    }

    public void removeMonster(int id) {
    
    LinkedList<Monster> newMonsters = new LinkedList<>();
    for (Monster monster : monsters) {
        if (monster.id != id) {
            newMonsters.add(monster);
        }
    }
    monsters = newMonsters;
    recreateTrees();
}

    public void removeDeadMonsters() {
    LinkedList<Monster> monstersToRemove = new LinkedList<>();
        for (Monster monster : monsters) {
        if (monster.health <= 0) {
            monstersToRemove.add(monster);
        }
    }
    
    for (Monster monster : monstersToRemove) {
        monsters.remove(monster);
    }
    
    recreateTrees();
}


    private void recreateTrees() {
        bstName = new BinarySearchTree();
        bstHealth = new BinarySearchTree();
        bstAttack = new BinarySearchTree();
        bstDefense = new BinarySearchTree();
        bstLevel = new BinarySearchTree();

        for (Monster monster : monsters) {
            bstName.insert(monster, "name");
            bstHealth.insert(monster, "health");
            bstAttack.insert(monster, "attack");
            bstDefense.insert(monster, "defense");
            bstLevel.insert(monster, "level");
        }
    }

    public void obtainSortedMonsters(String attribute) {
        switch (attribute.toLowerCase()) {
            case "name":
                bstName.traverseInOrder();
                break;
            case "health":
                bstHealth.traverseInOrder();
                break;
            case "attack":
                bstAttack.traverseInOrder();
                break;
            case "defense":
                bstDefense.traverseInOrder();
                break;
            case "level":
                bstLevel.traverseInOrder();
                break;
            default:
                System.out.println("Wrong attribute: " + attribute);
                break;
        }
    }
}
