/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bettlemonsterslast;

/**
 *
 * @author adaozcelik
 */
public class LinkedList {

    public Node first;
    public Node last;

    public void insertFirst(Monster data) {
        Node newNode = new Node(data);

        newNode.next = first;
        if (last == null) { 
            last = newNode;
        }
        first = newNode;
    }

    public void insertLast(Monster data) {
        Node newNode = new Node(data);
        if (last == null) { 
            first = newNode;
            last = newNode;
        } else {
            last.next = newNode;
            last = newNode;
        }
    }

    public void insertafter(Monster data, Node prev) { 
        Node newNode = new Node(data);
        newNode.next = prev.next;
        prev.next = newNode;
    }

    public Node search(Monster data) {
        Node tmp = first;
        while (tmp != null) {
            if (tmp.data == data) {
                return tmp;
            }
            tmp = tmp.next;
        }
        return null;
    }

    public void removeFirst() {
        if (first == null) {
            System.out.println("The list is already empty");
            return;
        }
        first = first.next;
    }

    public void removeLast() {
        if (first == null) {
            System.out.println("The list is already empty");
            return;
        }
        Node tmp = first.next;
        Node prev = first;
        while (tmp.next != null) { 
            tmp = tmp.next;
            prev = prev.next;
        }
        prev.next = null;
        last = prev;
    }

    public void removeAfter(Node prev) { 
        if (first == null) {
            System.out.println("The list is already empty.");
            return;
        }
        if (prev.next == null) {
            System.out.println("There are no elements after the previous.");
            return;
        }
        prev.next = prev.next.next;
    }

    @Override
    public String toString() {
        String s = "";
        Node tmp = first;
        while (tmp != null) {
            s += tmp.data + "->";
            tmp = tmp.next;
        }
        s += "Null";
        return s;
    }

}

